export interface Project {
  id: string;
  name: string;
  type: string;
  location: string;
  startDate: Date;
  status: string;
  createdAt: Date;
  updatedAt: Date;
}
