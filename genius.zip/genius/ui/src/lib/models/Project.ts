import type { Project as ProjectType } from '../types';

export class Project implements ProjectType {
  id: string;
  name: string;
  type: string;
  location: string;
  startDate: Date;
  status: string;
  createdAt: Date;
  updatedAt: Date;

  constructor({
    id = crypto.randomUUID(),
    name,
    type,
    location,
    startDate,
    status = 'PLANNING'
  }: Partial<ProjectType>) {
    this.id = id;
    this.name = name!;
    this.type = type!;
    this.location = location!;
    this.startDate = startDate!;
    this.status = status;
    this.createdAt = new Date();
    this.updatedAt = new Date();
  }

  update(updates: Partial<ProjectType>) {
    Object.assign(this, updates);
    this.updatedAt = new Date();
  }
}
