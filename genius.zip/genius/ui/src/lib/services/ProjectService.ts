import { Project } from '../models/Project';
import type { Project as ProjectType } from '../types';

export class ProjectService {
  private projects: Map<string, Project>;

  constructor() {
    this.projects = new Map();
  }

  createProject(projectData: Partial<ProjectType>) {
    const project = new Project(projectData);
    this.projects.set(project.id, project);
    return project;
  }

  updateProject(projectId: string, updates: Partial<ProjectType>) {
    const project = this.projects.get(projectId);
    if (!project) {
      throw new Error(`Project not found with id: ${projectId}`);
    }
    project.update(updates);
    return project;
  }

  getProject(projectId: string) {
    const project = this.projects.get(projectId);
    if (!project) {
      throw new Error(`Project not found with id: ${projectId}`);
    }
    return project;
  }

  listProjects(filters: { type?: string; status?: string } = {}) {
    let projects = Array.from(this.projects.values());
    
    if (filters.type) {
      projects = projects.filter(p => p.type === filters.type);
    }
    if (filters.status) {
      projects = projects.filter(p => p.status === filters.status);
    }
    
    return projects;
  }
}
